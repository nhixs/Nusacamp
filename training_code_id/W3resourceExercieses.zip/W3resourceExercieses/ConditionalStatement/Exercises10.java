/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W3resourceExercieses.ConditionalStatement;

/**
 *
 * @author Bagus
 */
public class Exercises10 {
    //10. Write a program in Java to display the first 10 natural numbers.
    public static void main(String[]args){
        for(int i=1; i<=10; i++){
            System.out.println(i);
        }
    }
}
